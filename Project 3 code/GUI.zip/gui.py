#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import Tkinter
def setpos1():
    turtle.setx(x)
    turtle.sety(y)
def setpos2():
    turtle.setx(x)
    turtle.sety(y)
def setpos3():
    turtle.setx(x)
    turtle.sety(y)
def setpos4():
    turtle.setx(x)
    turtle.sety(y)

def retrieve_input():
    input = self.entry.get("1.0",END)
    
    



def update_timeText():
  if (state):
    global timer
    #here is where you change the value of what it counts up/down in
    timer[2] += 1
    if (timer[2] >= 60):
        timer[2] = 0
        timer[1] += 1
    if (timer[1] >= 60):
        timer[0] += 1
        timer[1] = 0
    timeString = pattern.format(timer[0], timer[1], timer[2])
    return timeString

# Step 1        
global state      
global timer    
state = True
timer = [0, 0, 0]
pattern = '{0:02d}:{1:02d}:{2:02d}'

# Step 2
#every time this is called it prints the next number in the count down/up in
#the side window 

print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()
print update_timeText()


class simpleapp_tk(Tkinter.Tk):
    def __init__(self,parent):
        Tkinter.Tk.__init__(self,parent)
        self.parent = parent
        self.initialize()

    def set(self):
        print(self.entry.get())

    def initialize(self):
        self.grid()

        self.entry = Tkinter.Entry(self)
        self.entry.grid(column=0,row=1,sticky='EW')

        self.button = Tkinter.Button(self, text="Ammount of treasures", command=self.set)
        self.button.grid(column=1,row=0,sticky='EW')

        self.entry = Tkinter.Entry(self)
        self.entry.grid(column=0,row=0,sticky='EW')

        self.button = Tkinter.Button(self, text="Set time (s)", command=self.set)
        self.button.grid(column=1,row=1,sticky='EW')

        self.button = Tkinter.Button(self, text="set Position 1", command=setpos1)
        self.button.grid(column=1,row=3,sticky='EW')

        self.button = Tkinter.Button(self, text="set Position 2", command=setpos2)
        self.button.grid(column=1,row=2,sticky='EW')

        self.button = Tkinter.Button(self, text="set Position 3", command=setpos3)
        self.button.grid(column=0,row=3,sticky='EW')

        self.button = Tkinter.Button(self, text="set Position  4", command=setpos4)
        self.button.grid(column=0,row=2,sticky='EW')
      

if __name__ == "__main__":
    app = simpleapp_tk(None)
    app.mainloop()
